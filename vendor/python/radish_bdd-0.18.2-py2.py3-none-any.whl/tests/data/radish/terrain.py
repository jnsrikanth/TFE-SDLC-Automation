from radish import before


@before.all
def terrain_before_all(features, marker):
    pass
