class Hero(object):
    def __init__(self, forename, surname, hero):
        self.forename = forename
        self.surname = surname
        self.heroname = hero
