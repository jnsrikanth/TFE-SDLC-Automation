<template>
    <b-tab>
        <Glossary/>
    </b-tab>
</template>

<script>
import Glossary from '../components/Glossary';
export default {
    components: {Glossary}
}
</script>