<template>
    <b-tab>
        <Guidance />
    </b-tab>
</template>

<script>
import Guidance from '../components/Guidance';
export default {
    components: {Guidance}
}
</script>