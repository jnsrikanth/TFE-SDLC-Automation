__app_name__ = 'terraform_compliance'
__version__ = '1.14.1' if not '1.14.1'.startswith('{') else '0.0.0'
