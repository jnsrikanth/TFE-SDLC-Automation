"""Unit tests -- tests that verify the code of this egg in isolation"""
