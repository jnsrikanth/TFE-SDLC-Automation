"""For package documentation, see README"""

from .version import __version__

from .api import load, loads
from .transformer import END_LINE, START_LINE
